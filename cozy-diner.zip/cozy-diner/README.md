# cozy diner

A Pen created on CodePen.

Original URL: [https://codepen.io/goodlifegoodgames/pen/jEMroZZ](https://codepen.io/goodlifegoodgames/pen/jEMroZZ).

